<?php
header('location:index.php?m=admin');
?>
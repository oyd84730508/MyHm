<?php
return array (
  1 => 
  array (
    'siteid' => '1',
    'name' => '创盈集团',
    'dirname' => '',
    'domain' => 'http://www.chuanyin.com/',
    'site_title' => '创盈集团',
    'keywords' => '创盈金银,创盈集团,广东创盈金银经营有限公司',
    'description' => '创盈金银,创盈集团,广东创盈金银经营有限公司,全国客服热线: 4000-121-128',
    'release_point' => '',
    'default_style' => 'dcr',
    'template' => 'dcr',
    'setting' => 'array (
  \'upload_maxsize\' => \'52048\',
  \'upload_allowext\' => \'jpg|jpeg|gif|bmp|png|doc|docx|xls|xlsx|ppt|pptx|pdf|txt|rar|zip|swf\',
  \'watermark_enable\' => \'0\',
  \'watermark_minwidth\' => \'300\',
  \'watermark_minheight\' => \'300\',
  \'watermark_img\' => \'statics/images/water//mark.png\',
  \'watermark_pct\' => \'85\',
  \'watermark_quality\' => \'80\',
  \'watermark_pos\' => \'9\',
)',
    'uuid' => '4645de31-b0dc-11e9-a4b1-1831bfb5d24a',
    'url' => 'http://www.chuanyin.com/',
  ),
);
?>
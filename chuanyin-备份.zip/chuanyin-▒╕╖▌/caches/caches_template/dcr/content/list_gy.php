<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>
<div class="ins-grid duty" style="background:#fff url(<?php echo $CATEGORYS[$parentid]['image'];?>) top center no-repeat;">
	<div class="fn-clear w980 ins-wrap">
		<div class="fn-left sub-col">
			<div class="box cat">
				<div class="hd">
					<h2><?php echo $CATEGORYS[$parentid]['catname'];?></h2>
					<div class="small"><?php echo $CATEGORYS[$parentid]['description'];?></div>
				</div>
				<div class="bd">
					<ul>
						<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=2416d59f9d70868c8ffa9dc572995f91&action=category&catid=%24parentid&num=8&siteid=%24siteid&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>$parentid,'siteid'=>$siteid,'order'=>'listorder ASC','limit'=>'8',));}?>
						<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
						<li <?php if($r[catid] == $catid) { ?>class="select"<?php } ?>><a href="<?php echo $r['url'];?>"><?php echo $r['catname'];?></a></li>
						<?php $n++;}unset($n); ?>
						<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
					</ul>
				</div>
			</div>
			<div class="box">
				<!--<a href="brokers.php"><img src="images/sub_pic_1.jpg" alt="" /></a>-->
			</div>
		</div>
		<div class="fn-right main-wrap">
			<div class="breadcrumb">
				当前位置：<a href="<?php echo siteurl($siteid);?>">首页</a> <span><?php echo catpos($catid,'');?></span>
			</div>
			<div class="pic-list">
				<ul>
					<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=dadc66ca68ef857afa83715a78206314&action=lists&catid=%24catid&num=6&order=id+DESC&page=%24page\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$pagesize = 6;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$content_total = $content_tag->count(array('catid'=>$catid,'order'=>'id DESC','limit'=>$offset.",".$pagesize,'action'=>'lists',));$pages = pages($content_total, $page, $pagesize, $urlrule);$data = $content_tag->lists(array('catid'=>$catid,'order'=>'id DESC','limit'=>$offset.",".$pagesize,'action'=>'lists',));}?>
					<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
					<li class="fn-clear">
						<div class="fn-left pic-area">
							<a href="<?php echo $r['url'];?>"><img src="<?php echo $r['thumb'];?>" alt="" /></a>
						</div>
						<div class="fn-right text-area">
							<h4><a href="<?php echo $r['url'];?>"><?php echo $r['title'];?></a></h4>
							<p><?php echo $r['description'];?></p>
							<a href="<?php echo $r['url'];?>"><img src="<?php echo WEB_PATH;?>public/images/pic_list_more.jpg" alt="" /></a>
						</div>
					</li>
					<?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
				 </ul>
			</div>
			<div class="pagelist"><?php echo $pages;?></div>
		</div>
	</div>

	<div class="w980 ins-wrap-b"></div>

</div>
<?php include template("content","header"); ?>
</body>
</html>

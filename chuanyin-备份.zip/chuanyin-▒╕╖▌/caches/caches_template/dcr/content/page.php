<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>
<script type="text/javascript" src="<?php echo WEB_PATH;?>public/js/jscroll.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$(".j-con").jscroll({
			W:"8px",
			BgUrl:"url(<?php echo WEB_PATH;?>public/images/scroll.png)",
			Bg:"-45px 0 repeat-y",
			Bar:{Pos:"",
				Bd:{Out:"#ae1d29",Hover:"#ae1d29"},
				Bg:{Out:"-1px center repeat-y",Hover:"-12px center repeat-y",Focus:"-23px center repeat-y"}
			},
			Btn:{btn:false}
		});
	})
</script>
<div class="grid">
	<div class="banner">
		<img src="<?php echo $CAT['image'];?>" alt="" />
	</div>
	<div class="fn-clear page-wrap">
		<div class="fn-left j-pic"><img src="<?php echo $CAT['image2'];?>" alt="" /></div>
		<div class="fn-right j-box">
			<h2><?php echo $CAT['catname'];?></h2>
			<div class="small"><?php echo $CAT['description'];?></div>
			<div class="j-switch">
				<ul class="fn-clear">
				</ul>
			</div>
			<div class="j-con">
      			<?php echo $content;?>
			</div>
		</div>
	</div>
</div>
<?php include template("content","footer"); ?>
</body>
</html>

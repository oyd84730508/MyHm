<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>

<div class="ins-grid contact" style="background:#fff url(<?php echo $CAT['image'];?>) top center no-repeat;">
	<div class="fn-clear w980 ins-wrap">
		<div class="fn-left sub-col">
			<div class="box cat">
				<div class="hd">
					<h2><?php echo $CAT['catname'];?></h2>
					<div class="small"><?php echo $CAT['description'];?></div>
				</div>
				<div class="bd">
					<ul>
						<li class="select"><a href="<?php echo $CAT['url'];?>"><?php echo $CAT['catname'];?></a></li>
					</ul>
				</div>
			</div>
			<div class="box">
				<!--<a href="brokers.php"><img src="<?php echo WEB_PATH;?>public/images/sub_pic_1.jpg" alt="" /></a>-->
			</div>
		</div>
		<div class="fn-right main-wrap">
			<div class="breadcrumb">
			当前位置：<a href="<?php echo siteurl($siteid);?>">首页</a> <span><?php echo catpos($catid,'');?></span>
			</div>
			<div class="ins-con">
				<img title="" src="<?php echo WEB_PATH;?>public/images/20141030151047_74778.png" alt="" align="right" height="200" width="200" />
				<?php echo $content;?>
				<div class="container"><div id="cmap"><img src="<?php echo WEB_PATH;?>public/images/map.jpg"></div></div>
			</div>
		</div>
	</div>
	<div class="w980 ins-wrap-b"></div>
</div>
<?php include template("content","footer"); ?>
<script type="text/javascript" src="https://api.map.baidu.com/api?v=1.3"></script>
<script type="text/javascript">
/*var map 	= new BMap.Map("cmap");
var myGeo 	= new BMap.Geocoder();
map.enableScrollWheelZoom();
map.enableInertialDragging();
var searchLocation = function(where,city){
	myGeo.getPoint(where, function(point){
		if (point) {
			map.centerAndZoom(point, 17);
			var marker = new BMap.Marker(point);
			map.addOverlay(marker);
			marker.setAnimation(BMAP_ANIMATION_BOUNCE);	
			var opts = {
				width : 250,
				height: 100,
				title : "广东创盈金银经营有限公司<br>电话：4000-121-128"
				}
			var infoWindow = new BMap.InfoWindow("广州市环市东路326号广东亚洲国际大酒店22楼", opts);
			marker.addEventListener("click", function(){          
				this.openInfoWindow(infoWindow);  
				})
				}
			}, city);
	}
searchLocation("广东亚洲国际大酒店","广州");*/
</script>
</body>
</html>
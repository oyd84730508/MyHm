<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>
<div class="ins-grid industry" style="background:#fff url(<?php echo $CAT['image'];?>) top center no-repeat;">
	<div class="fn-clear w980 ins-wrap">
		<div class="fn-left sub-col">
			<div class="box cat">
				<div class="hd">
					<h2><?php echo $CAT['catname'];?></h2>
					<div class="small">GROUP INDUSTRY</div>
				</div>
				<div class="bd">
					<ul>
						<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=f4363ab634fbb4ed361417c711078313&action=lists&catid=%24catid&num=8&siteid=%24siteid&order=listorder+DESC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'siteid'=>$siteid,'order'=>'listorder DESC','limit'=>'8',));}?>
						<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
						<li <?php if($id == $r[id]) { ?>class="select"<?php } ?>><a href="<?php echo $r['url'];?>"><?php echo $r['title'];?></a></li>
						<?php $n++;}unset($n); ?>
						<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
					</ul>
				</div>
			</div>
			<div class="box">
			</div>
		</div>
		<div class="fn-right main-wrap">
			<div class="breadcrumb">
				当前位置：<a href="<?php echo siteurl($siteid);?>">首页</a> <span><?php echo catpos($catid,'');?></span> <?php echo $title;?>
			</div>
			<div class="ins-con">
				<?php echo $content;?>
			</div>
		</div>
		<div class="w980 ins-wrap-b"></div>
</div>
<?php include template("content","footer"); ?>
</body>
</html>

<?php

return array (
	'default' => array (
		'hostname' => '127.0.0.1',
		'port' => 3306,
		'database' => 'sq_sy',
		'username' => 'root',
		'password' => '123456',
		'tablepre' => 'v9_',
		'charset' => 'utf8mb4',
		'type' => 'mysqli',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
);

?>
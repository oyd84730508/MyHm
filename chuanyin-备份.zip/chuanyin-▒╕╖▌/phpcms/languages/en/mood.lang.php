<?php
$LANG['id_cannot_be_empty'] = 'ID is required';
$LANG['total'] = 'Total';
$LANG['expressed'] = 'You have already expressed your feelings. Have a nice day! ';
$LANG['category'] = 'Column';
$LANG['time'] = 'Time';
$LANG['sort'] = 'Ordering';
$LANG['today'] = 'Today';
$LANG['yesterday'] = 'Yesterday';
$LANG['this_week'] = 'This week';
$LANG['this_month'] = 'This month';
$LANG['all'] = 'All';
$LANG['view'] = 'View';
$LANG['title'] = 'Title';
$LANG['on_hand'] = 'Available';
$LANG['name'] = 'Name';
$LANG['pic'] = 'Photo';
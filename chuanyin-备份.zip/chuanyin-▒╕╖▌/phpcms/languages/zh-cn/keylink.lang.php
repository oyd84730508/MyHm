<?php
$LANG['add_keylink']				=	'添加关联链接';
$LANG['keylink_name']				=	'关键词';
$LANG['link_address']				=	'联接';
?>
<?php
return array (
  2 => '3',
  7 => '2',
);
?>
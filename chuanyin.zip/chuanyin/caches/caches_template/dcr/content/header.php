<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo $SEO['title'];?><?php } ?><?php echo $SEO['site_title'];?></title>
    <meta name="keywords" content="<?php echo $SEO['keyword'];?>">
    <meta name="description" content="<?php echo $SEO['description'];?>">
    <link rel="stylesheet" href="<?php echo WEB_PATH;?>public/css/style.css">
    <script type="text/javascript" src="<?php echo WEB_PATH;?>public/js/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo WEB_PATH;?>public/js/common.js"></script>
</head>
<body>
<div class="header">
    <div class="w980">
        <a href="<?php echo WEB_PATH;?>" class="logo" style="width: 180px;height: 60px;background: none;"><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=4c9b13a7b279c1a1ccf5bb639aab032c&pos=header_logo\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'header_logo',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></a>
        <div class="nav">
            <ul class="fn-clear">
                <li  <?php if(!$catid) { ?> class="index"<?php } ?>>
                <a href="<?php echo WEB_PATH;?>">首页</a>
                </li>
                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=522dcf79f84779c8c187ca374072cc0d&action=category&catid=0&num=8&siteid=%24siteid&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">修改</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>'0','siteid'=>$siteid,'order'=>'listorder ASC','limit'=>'8',));}?>
                <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
                <li  <?php if($catid == $r[catid] || $top_parentid == $r[catid]) { ?>class="index"<?php } ?>>
                <a href="<?php echo $r['url'];?>"><?php echo $r['catname'];?></a>
                <?php if($r[catid] == 2) { ?>
                <div class="son s-in">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=a8a437d3e216effe3bb1a2c22f1640c3&action=lists&catid=%24r%5Bcatid%5D&num=8&order=listorder+DESC&return=data2\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">修改</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data2 = $content_tag->lists(array('catid'=>$r[catid],'order'=>'listorder DESC','limit'=>'8',));}?>
                    <?php $n=1;if(is_array($data2)) foreach($data2 AS $rr) { ?>
                    <a href="<?php echo $rr['url'];?>"><?php echo $rr['title'];?></a>
                    <?php $n++;}unset($n); ?>
                    <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </div>
                <?php } ?>
                <?php $data3 = subcat($r[catid])?>
                <?php if($data3) { ?>
                <div class="son s-duty">
                    <?php $n=1;if(is_array($data3)) foreach($data3 AS $rrr) { ?>
                    <a href="<?php echo $rrr['url'];?>"><?php echo $rrr['catname'];?></a>
                    <?php $n++;}unset($n); ?>
                </div>
                <?php } ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </li>
                <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
    </div>
    <div class="shadow"></div>
</div>
<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?>﻿<?php include template("content","header"); ?>
<div class="grid" >
	<div class="banner">
		<ul>
			<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=780c79fc5d15cf70b299ff1d3740a311&action=lists&catid=8&num=1&siteid=%24siteid&order=listorder+DESC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'8','siteid'=>$siteid,'order'=>'listorder DESC','limit'=>'1',));}?>
			<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
			<li><div id="div1"><img src="<?php echo $r['thumb'];?>" alt="<?php echo $r['title'];?>" /></div></li>
			<?php $n++;}unset($n); ?>
			<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
		</ul>
	</div>
	<!-- <div class="banner-btn"></div> -->
	<div class="website">
		<ul>
			<!-- <li><a href="">
					<img src="<?php echo WEB_PATH;?>public/images/c_1.jpg" alt="" />
					<h4></h4>
					<p></p>
				</a></li> -->
		</ul>
	</div>
</div>

<div class="footer_banner">
	<?php include template("content","footer"); ?>
</div>
</body>
</html>

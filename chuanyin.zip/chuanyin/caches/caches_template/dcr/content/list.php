<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>
<div class="ins-grid industry" style="background:#fff url(<?php echo $CAT['image'];?>) top center no-repeat;">
	<div class="fn-clear w980 ins-wrap">
		<div class="fn-left sub-col">
			<div class="box cat">
				<div class="hd">
					<h2><?php echo $CAT['catname'];?></h2>
					<div class="small">GROUP INDUSTRY</div>
				</div>
				<div class="bd">
					<ul>
						<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=f4363ab634fbb4ed361417c711078313&action=lists&catid=%24catid&num=8&siteid=%24siteid&order=listorder+DESC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'siteid'=>$siteid,'order'=>'listorder DESC','limit'=>'8',));}?>
						<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
						<li><a href="<?php echo $r['url'];?>"><?php echo $r['title'];?></a></li>
						<?php $n++;}unset($n); ?>
						<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
					</ul>
				</div>
			</div>
			<div class="box">
			</div>
		</div>
		<div class="fn-right main-wrap">
			<div class="breadcrumb">
				当前位置：<a href="<?php echo siteurl($siteid);?>">首页</a> <span><?php echo catpos($catid,'');?></span>
			</div>

			<div class="ins-intro">
				<h1><?php echo $CAT['catname'];?></h1>
				<p><?php echo $CAT['description'];?></p>
			</div>
			<h3>投资项目</h3>
			<div class="pic-list">
				<ul>
					<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c5a6be69e3ce286e9828d6f07005c11f&action=lists&catid=%24catid&num=8&siteid=%24siteid&order=listorder+DESC&page=%24page\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$pagesize = 8;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$content_total = $content_tag->count(array('catid'=>$catid,'siteid'=>$siteid,'order'=>'listorder DESC','limit'=>$offset.",".$pagesize,'action'=>'lists',));$pages = pages($content_total, $page, $pagesize, $urlrule);$data = $content_tag->lists(array('catid'=>$catid,'siteid'=>$siteid,'order'=>'listorder DESC','limit'=>$offset.",".$pagesize,'action'=>'lists',));}?>
					<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
					<li class="fn-clear">
						<div class="fn-left pic-area">
							<a href="<?php echo $r['url'];?>"><img src="<?php echo $r['thumb'];?>" alt="" /></a>
						</div>
						<div class="fn-right text-area">
							<h4><a href="<?php echo $r['url'];?>"><?php echo $r['title'];?></a></h4>
							<p><?php echo $r['description'];?></p>
							<a href="<?php echo $r['url'];?>"><img src="<?php echo WEB_PATH;?>public/images/pic_list_more.jpg" alt="" /></a>
						</div>
					</li>
					<?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
				</ul>
			</div>
			<div class="pagelist"><?php echo $pages;?></div>
		</div>
	</div>
	<div class="w980 ins-wrap-b"></div>
</div>
<?php include template("content","footer"); ?>
</body>
</html>

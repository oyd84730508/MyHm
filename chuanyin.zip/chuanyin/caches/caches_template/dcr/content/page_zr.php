<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>
<div class="ins-grid duty" style="background:#fff url(<?php echo $CAT['image'];?>) top center no-repeat;">
	<div class="fn-clear w980 ins-wrap">
		<div class="fn-left sub-col">
			<div class="box cat">
				<div class="hd">
					<h2><?php echo $CAT['catname'];?></h2>
					<div class="small"><?php echo $CAT['description'];?></div>
				</div>
				<div class="bd">
					<ul>
						<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=335a08dda250e55d962c47d9e5c43e04&action=category&catid=%24catid&num=8&siteid=%24siteid&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>$catid,'siteid'=>$siteid,'order'=>'listorder ASC','limit'=>'8',));}?>
						<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
						<li <?php if($r[catid] == 6) { ?>class="select"<?php } ?>><a href="<?php echo $r['url'];?>"><?php echo $r['catname'];?></a></li>
						<?php $n++;}unset($n); ?>
						<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
					</ul>
				</div>
			</div>
			<div class="box">
				<!--<a href="brokers.php"><img src="images/sub_pic_1.jpg" alt="" /></a>-->
			</div>
		</div>
		<div class="fn-right main-wrap">
			<div class="breadcrumb">
				当前位置：<a href="<?php echo siteurl($siteid);?>">首页</a> <span><?php echo catpos($catid,'');?></span>
			</div>

			<div class="ins-con">
				<?php $pageDb = pc_base::load_model('page_model');$pageInfo=$pageDb->get_one('catid=6');?>
				<?php echo $pageInfo['content'];?>
			</div>
		</div>
	</div>
	<div class="w980 ins-wrap-b"></div>
</div>
<?php include template("content","footer"); ?>
</body>
</html>

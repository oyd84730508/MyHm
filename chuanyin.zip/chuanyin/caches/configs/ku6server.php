<?php
return array(
	//站外视频上传接口地址
	'api_url' => 'http://juhe.phpcms.cn/v5/api',
	'api' => 'http://juhe.phpcms.cn/api/',
	'player_url' => 'http://player.juhe.phpcms.cn/player.php/vid/', 
);
?>
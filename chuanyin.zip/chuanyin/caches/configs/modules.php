<?php
return array (
  'member' => '会员',
  'special' => '专题',
  'content' => '内容模块',
  'announce' => '公告',
  'link' => '友情链接',
);
?>
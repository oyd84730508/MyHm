<?php exit;?>07-28 10:13:29 | 2 | fsockopen(): php_network_getaddresses: getaddrinfo failed: ����������Ч�������Ҳ����������͵���ݡ�  | phpcms\libs\classes\http.class.php | 84
<?php exit;?>07-28 10:13:29 | 2 | fsockopen(): unable to connect to juhe.phpcms.cn:80 (php_network_getaddresses: getaddrinfo failed: ����������Ч�������Ҳ����������͵���ݡ� ) | phpcms\libs\classes\http.class.php | 84
<?php exit;?>07-28 10:43:04 | 2 | extract() expects parameter 1 to be array, null given | phpcms\modules\content\classes\html.class.php | 182
<?php exit;?>07-28 11:07:29 | 2 | extract() expects parameter 1 to be array, null given | phpcms\modules\content\classes\html.class.php | 182
<?php exit;?>07-28 11:36:47 | 8192 | Function split() is deprecated | caches\caches_model\caches_data\content_update.class.php | 70
<?php exit;?>07-28 11:37:20 | 8192 | Function split() is deprecated | caches\caches_model\caches_data\content_update.class.php | 70
<?php exit;?>07-28 11:47:11 | 2 | extract() expects parameter 1 to be array, null given | phpcms\modules\content\classes\html.class.php | 182
<?php exit;?>07-28 11:47:47 | 2 | extract() expects parameter 1 to be array, null given | phpcms\modules\content\classes\html.class.php | 182
<?php exit;?>07-28 11:59:53 | 8192 | Function split() is deprecated | caches\caches_model\caches_data\content_update.class.php | 70
<?php exit;?>07-28 14:07:11 | 8192 | Function split() is deprecated | caches\caches_model\caches_data\content_update.class.php | 70
<?php exit;?>07-28 14:08:10 | 8192 | Function split() is deprecated | caches\caches_model\caches_data\content_update.class.php | 70
<?php exit;?>07-29 09:44:22 | 2 | mysqli::mysqli(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) | phpcms\libs\classes\db_mysqli.class.php | 56
<?php exit;?>07-29 09:44:22 | 2 | db_mysqli::error(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 385
<?php exit;?>07-29 09:44:22 | 2 | db_mysqli::errno(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 389
<?php exit;?>07-29 09:44:22 | 2 | db_mysqli::errno(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 389
<?php exit;?>07-29 09:44:22 | 2 | db_mysqli::error(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 385
<?php exit;?>07-29 09:44:22 | 2 | mysqli::close(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 401
<?php exit;?>07-29 09:44:26 | 2 | mysqli::mysqli(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) | phpcms\libs\classes\db_mysqli.class.php | 56
<?php exit;?>07-29 09:44:26 | 2 | db_mysqli::error(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 385
<?php exit;?>07-29 09:44:26 | 2 | db_mysqli::errno(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 389
<?php exit;?>07-29 09:44:26 | 2 | db_mysqli::errno(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 389
<?php exit;?>07-29 09:44:26 | 2 | db_mysqli::error(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 385
<?php exit;?>07-29 09:44:26 | 2 | mysqli::close(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 401
